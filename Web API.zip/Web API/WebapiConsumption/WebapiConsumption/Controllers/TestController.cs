﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using WebapiConsumption.Models;

namespace WebapiConsumption.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public void myfunc( string Userid)
        {
            var y = Userid.ToString();
            var x = y.ToString();
        }

        //Hosted web API REST Service base url  
        string Baseurl = "http://addonexus.azurewebsites.net/";
        public async Task<ActionResult> Getter()
        {
            List<Account> EmpInfo = new List<Account>();

            using (var client = new HttpClient())
            {
                //Passing service base url  
                client.BaseAddress = new Uri(Baseurl);

                client.DefaultRequestHeaders.Clear();
                //Define request data format  
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                //Sending request to find web api REST service resource GetAllEmployees using HttpClient  
                HttpResponseMessage Res = await client.GetAsync("api/Account/");

                //Checking the response is successful or not which is sent using HttpClient  
                if (Res.IsSuccessStatusCode)
                {
                    //Storing the response details recieved from web api   
                    var EmpResponse = Res.Content.ReadAsStringAsync().Result;

                    //Deserializing the response recieved from web api and storing into the Employee list  
                    EmpInfo = JsonConvert.DeserializeObject<List<Account>>(EmpResponse);

                }
                //returning the employee list to view  
                return View(EmpInfo);
            }
        }
        public class symptoms
        {
            public int Id { get; set; }
            public int UserID { get; set; }
            public DateTime DateTime { get; set; }
            public String WeightLossYes { get; set; }
            public String AnxietyYes { get; set; }
            public String ChestPainYes { get; set; }
            public string AdverseMedicineNo { get; set; }

        }
        public class Numericdata
        {
            public int Id { get; set; }
            public int UserID { get; set; }
            public DateTime DateTime { get; set; }
            public String BodyTemp { get; set; }
            public String Systolic { get; set; }    //Uper Bp
            public String Diastolic { get; set; }   //Lower Bp
            public String Pulse { get; set; }

            public String Weight { get; set; }
            public String Height { get; set; }
        }
        public void symptomPoster ()
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://addonexus.azurewebsites.net/api/Symptoms");
                symptoms x = new symptoms();
               
                x.UserID = 7;
                x.AdverseMedicineNo = "No";
                x.AnxietyYes= "Yes";
                x.ChestPainYes = "Yes";
                x.DateTime= DateTime.Now;
                


                //HTTP POST
                var postTask = client.PostAsJsonAsync<symptoms>("Symptoms", x);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    Response.Write("Succesfull");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

          
        }


        public void DeleteData()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://addonexus.azurewebsites.net/");
                var response = client.DeleteAsync("api/NumericData/16").Result;
                if (response.IsSuccessStatusCode)
                {
                    Response.Write("Success");
                }
                else
                    Response.Write("Error");
            }
        }

        public void NumericDataPoster()
        {

            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://addonexus.azurewebsites.net/api/NumericData");
                Numericdata x = new Numericdata();
           
                x.UserID = 7;
                x.BodyTemp = "99";
                x.Systolic = "103";
                x.Diastolic = "78";
                x.Pulse= "85 BPM";
                x.DateTime = DateTime.Now;
                x.Weight = "72KG";
                x.Height="5'10";


                //HTTP POST
                var postTask = client.PostAsJsonAsync<Numericdata>("Numericdata", x);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    Response.Write("Succesfull");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");


        }

        public void Delete()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://addonexus.azurewebsites.net/api/");
                string id = "21";
                //HTTP DELETE
                var deleteTask = client.DeleteAsync("NumericData/" + id.ToString());
                deleteTask.Wait();

                var result = deleteTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    Response.Write("Success");
                }
            }
            Response.Write("Not Success");
        }


        public ActionResult PostMan()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://addonexus.azurewebsites.net/api/account/login");
                Account x = new Account();
                x.Id = 2;
                x.Age = "22";
                x.Email = "daniyalshah729@yahoo.com";
                x.FirstName = "Daniyal";
                x.LastName = "Shah";
                x.JoinDate = DateTime.Now;
                x.Password = "AbcD";
                x.ConfirmPassword = "AbcD";
                

                //HTTP POST
                var postTask = client.PostAsJsonAsync<Account>("Account", x);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    return RedirectToAction("Index");
                }
            }

            ModelState.AddModelError(string.Empty, "Server Error. Please contact administrator.");

            return View();
            
        }
    }
}